-------------------------------------------------------------------------------
-- (C) Altran Praxis Limited
-------------------------------------------------------------------------------
--
-- The SPARK toolset is free software; you can redistribute it and/or modify it
-- under terms of the GNU General Public License as published by the Free
-- Software Foundation; either version 3, or (at your option) any later
-- version. The SPARK toolset is distributed in the hope that it will be
-- useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
-- Public License for more details. You should have received a copy of the GNU
-- General Public License distributed with the SPARK toolset; see file
-- COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
-- the license.
--
--=============================================================================

-------------------------------------------------------------------------------
--                                                                           --
-- SPARK.Ada.Strings                                                         --
--                                                                           --
-- Description                                                               --
--   This is a binding to package Ada.Strings                                --
--                                                                           --
-- Language                                                                  --
--   Specification : SPARK                                                   --
--   Private Part  : N/A                                                     --
--   Body          : N/A                                                     --
--                                                                           --
-- Runtime Requirements and Dependencies                                     --
--   No Ada Runtime                                                          --
--                                                                           --
-- Verification                                                              --
--   N/A                                                                     --
--                                                                           --
-- Exceptions                                                                --
--   None                                                                    --
--                                                                           --
-------------------------------------------------------------------------------

package SPARK.Ada.Strings is

   Space : constant Character := ' ';

   --  type Alignment  is (Left, Right, Center);
   type Alignment is (Alignment_Left, Alignment_Right, Alignment_Center);
   --  type Truncation is (Left, Right, Error);
   type Truncation is (Truncation_Left, Truncation_Right, Truncation_Error);
   --  type Membership is (Inside, Outside);
   type Membership is (Membership_Inside, Membership_Outside);
   --  type Direction  is (Forward, Backward);
   type Direction is (Direction_Forward, Direction_Backward);
   --  type Trim_End   is (Left, Right, Both);
   type Trim_End is (Trim_End_Left, Trim_End_Right, Trim_End_Both);

end SPARK.Ada.Strings;
