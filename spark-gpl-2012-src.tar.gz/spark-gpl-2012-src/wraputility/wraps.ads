-------------------------------------------------------------------------------
-- (C) Altran Praxis Limited
-------------------------------------------------------------------------------
--
-- The SPARK toolset is free software; you can redistribute it and/or modify it
-- under terms of the GNU General Public License as published by the Free
-- Software Foundation; either version 3, or (at your option) any later
-- version. The SPARK toolset is distributed in the hope that it will be
-- useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
-- Public License for more details. You should have received a copy of the GNU
-- General Public License distributed with the SPARK toolset; see file
-- COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
-- the license.
--
--=============================================================================

--------------------------------------------------------------------------------
-- This program reads in a .PFS (path functions) or .VCS (verification        --
-- conditions) file and truncates lines which are over eighty characters in   --
-- length.  Where a line exceeds 80 characters, the utility attempts to find  --
-- convenient points in the line (with an intervening space character) at     --
-- which to insert line breaks, and indents by ten columns after the break.   --
--------------------------------------------------------------------------------

--# inherit SPARK_IO;
package WRAPS is

   procedure WRAP;
   --# global in out SPARK_IO.File_Sys;
   --# derives SPARK_IO.File_Sys from *;

end WRAPS;
