-------------------------------------------------------------------------------
-- (C) Altran Praxis Limited
-------------------------------------------------------------------------------
--
-- The SPARK toolset is free software; you can redistribute it and/or modify it
-- under terms of the GNU General Public License as published by the Free
-- Software Foundation; either version 3, or (at your option) any later
-- version. The SPARK toolset is distributed in the hope that it will be
-- useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
-- Public License for more details. You should have received a copy of the GNU
-- General Public License distributed with the SPARK toolset; see file
-- COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
-- the license.
--
--=============================================================================

package Version
is
   type Distribution_Sort is (Pro, GPL);
   Toolset_Distribution_Sort : constant Distribution_Sort := GPL;
   --# accept W, 3, "Pragma to suppress compiler warnings for this constant";
   pragma Warnings (Off, Toolset_Distribution_Sort);

   Toolset_Version       : constant String := "2012";
   Toolset_Copyright     : constant String := "Copyright (C) 2012 Altran Praxis Limited, Bath, U.K.";
   Toolset_Distribution  : constant String := "GPL";
   Toolset_Banner_Line   : constant String := "GPL 2012";
   Toolset_Support_Line1 : constant String := "";
   Toolset_Support_Line2 : constant String := "Report bugs to: spark@adacore.com";
   Toolset_Support_Line3 : constant String := "";
   Toolset_Support_Line4 : constant String := "";
end Version;
