-------------------------------------------------------------------------------
-- (C) Altran Praxis Limited
-------------------------------------------------------------------------------
--
-- The SPARK toolset is free software; you can redistribute it and/or modify it
-- under terms of the GNU General Public License as published by the Free
-- Software Foundation; either version 3, or (at your option) any later
-- version. The SPARK toolset is distributed in the hope that it will be
-- useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
-- Public License for more details. You should have received a copy of the GNU
-- General Public License distributed with the SPARK toolset; see file
-- COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
-- the license.
--
--=============================================================================

separate (Sem)
function Illegal_Unconstrained (Left_Type, Right_Type : Dictionary.Symbol) return Boolean is
   Result : Boolean;
begin
   -- at the point where this is called we know that the RHS/LHS base types are the same.
   -- We are interested in the case where LHS and RHS are differently
   -- constrained subtypes of a common unconstrained base type.
   Result := False;

   if Dictionary.IsUnconstrainedArrayType (Dictionary.GetRootType (Right_Type)) then
      Result := not Indexes_Match (Target => Left_Type,
                                   Source => Right_Type);
   end if;
   return Result;
end Illegal_Unconstrained;
