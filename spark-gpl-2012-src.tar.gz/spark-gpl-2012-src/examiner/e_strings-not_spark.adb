-------------------------------------------------------------------------------
-- (C) Altran Praxis Limited
-------------------------------------------------------------------------------
--
-- The SPARK toolset is free software; you can redistribute it and/or modify it
-- under terms of the GNU General Public License as published by the Free
-- Software Foundation; either version 3, or (at your option) any later
-- version. The SPARK toolset is distributed in the hope that it will be
-- useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
-- Public License for more details. You should have received a copy of the GNU
-- General Public License distributed with the SPARK toolset; see file
-- COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
-- the license.
--
--=============================================================================

with SPARK.Ada.Strings.Unbounded.Not_SPARK;

package body E_Strings.Not_SPARK is
   --# hide E_Strings.Not_SPARK;

   function Get_String (E_Str : E_Strings.T) return String is
   begin
      return SPARK.Ada.Strings.Unbounded.Not_SPARK.To_String (Source => E_Str.Content);
   end Get_String;

end E_Strings.Not_SPARK;
