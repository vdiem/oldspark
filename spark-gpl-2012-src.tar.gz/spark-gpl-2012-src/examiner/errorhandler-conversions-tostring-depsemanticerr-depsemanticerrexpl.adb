separate (ErrorHandler.Conversions.ToString.DepSemanticErr)
procedure DepSemanticErrExpl (E_Str   : in out E_Strings.T)

is
begin
   case Err_Num.ErrorNum is
      when 1 =>
         E_Strings.Append_String
            (E_Str => E_Str,
             Str   => "XXX occurred as an export in the earlier dependency relation but" &
              " neither XXX nor any refinement constituent of it occurs in the" &
              " refined dependency relation.");
      when 2 =>
         E_Strings.Append_String
            (E_Str => E_Str,
             Str   => "A refinement constituent of XXX occurs as an export in the" &
              " refined dependency relation but XXX does not occur as an export in" &
              " the earlier dependency relation.");
      when 3 =>
         E_Strings.Append_String
            (E_Str => E_Str,
             Str   => "The dependency of the exported value of XXX on the imported value" &
              " of YYY occurs in the earlier dependency relation but in the refined" &
              " dependency relation, no constituents of XXX" &
              " depend on any constituents of YYY.");
      when 4 =>
         E_Strings.Append_String
            (E_Str => E_Str,
             Str   => "A refined dependency relation states a dependency of XXX or a" &
              " constituent of XXX on YYY or a constituent of YYY, but in the" &
              " earlier relation, no dependency of XXX on YYY is stated.");
      when 5 =>
         E_Strings.Append_String
            (E_Str => E_Str,
             Str   => "Either a dependency of a constituent of XXX on at least one" &
              " constituent of XXX occurs in the refined dependency relation, or" &
              " not all the constituents of XXX occur as exports in" &
              " the refined dependency relation. However, the dependency of XXX on" &
              " itself does not occur in the earlier dependency relation.");
      when others => null;
   end case;
end DepSemanticErrExpl;
