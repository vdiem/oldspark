-------------------------------------------------------------------------------
-- (C) Altran Praxis Limited
-------------------------------------------------------------------------------
--
-- The SPARK toolset is free software; you can redistribute it and/or modify it
-- under terms of the GNU General Public License as published by the Free
-- Software Foundation; either version 3, or (at your option) any later
-- version. The SPARK toolset is distributed in the hope that it will be
-- useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
-- Public License for more details. You should have received a copy of the GNU
-- General Public License distributed with the SPARK toolset; see file
-- COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
-- the license.
--
--=============================================================================

separate (Sem)
function Unexpected_Initialization (Sym : Dictionary.Symbol) return Boolean is
begin
   return -- not an initialized own variable
     ((Dictionary.IsOwnVariable (Sym) and then not Dictionary.OwnVariableIsInitialized (Sym))
      or else
        -- not an initialized constituent
        (Dictionary.IsConstituent (Sym) and then not Dictionary.OwnVariableIsInitialized (Dictionary.GetSubject (Sym))))
     and then
     -- not moded (this last limb to suppress error 333 for stream vars
     Dictionary.GetOwnVariableOrConstituentMode (Sym) = Dictionary.DefaultMode;
end Unexpected_Initialization;
