-------------------------------------------------------------------------------
-- (C) Altran Praxis Limited
-------------------------------------------------------------------------------
--
-- The SPARK toolset is free software; you can redistribute it and/or modify it
-- under terms of the GNU General Public License as published by the Free
-- Software Foundation; either version 3, or (at your option) any later
-- version. The SPARK toolset is distributed in the hope that it will be
-- useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
-- Public License for more details. You should have received a copy of the GNU
-- General Public License distributed with the SPARK toolset; see file
-- COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
-- the license.
--
--=============================================================================

--  Run-time symbolic traceback support
--
--  SPECIAL NULL VERSION FOR GCC 4.x on OSX/Darwin where this package
--  is not currently supported.  This body is only compiled on OSX/Darwin
--  platforms.  On all other GNAT Pro supported platforms the full,
--  working version of this package is used from the standard GNAT runtime.
--
--  This file has been derived from the standard version of this
--  package body in the GNAT runtime library.
package body GNAT.Traceback.Symbolic is

   ------------------------
   -- Symbolic_Traceback --
   ------------------------

   function Symbolic_Traceback (Traceback : Tracebacks_Array) return String is
   begin
      return "";
   end Symbolic_Traceback;

   function Symbolic_Traceback (E : Exception_Occurrence) return String is
   begin
      return "";
   end Symbolic_Traceback;

end GNAT.Traceback.Symbolic;
