-------------------------------------------------------------------------------
-- (C) Altran Praxis Limited
-------------------------------------------------------------------------------
--
-- The SPARK toolset is free software; you can redistribute it and/or modify it
-- under terms of the GNU General Public License as published by the Free
-- Software Foundation; either version 3, or (at your option) any later
-- version. The SPARK toolset is distributed in the hope that it will be
-- useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
-- Public License for more details. You should have received a copy of the GNU
-- General Public License distributed with the SPARK toolset; see file
-- COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
-- the license.
--
--=============================================================================

separate (Sem)
procedure Wf_Context_Clause (Node     : in STree.SyntaxNode;
                             Comp_Sym : in Dictionary.Symbol;
                             Scope    : in Dictionary.Scopes) is
   Always_False : Boolean;
   pragma Unreferenced (Always_False);
begin
   --# accept F, 10, Always_False, "A specification can never with its own child" &
   --#        F, 33, Always_False, "A specification can never with its own child";
   Wf_Context_Clause_Package_Body (Node              => Node,
                                   Comp_Sym          => Comp_Sym,
                                   Scope             => Scope,
                                   With_Public_Child => Always_False);
end Wf_Context_Clause;
