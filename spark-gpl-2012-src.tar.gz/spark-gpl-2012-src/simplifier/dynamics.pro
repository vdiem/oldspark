% -----------------------------------------------------------------------------
%  (C) Altran Praxis Limited
% -----------------------------------------------------------------------------
% 
%  The SPARK toolset is free software; you can redistribute it and/or modify it
%  under terms of the GNU General Public License as published by the Free
%  Software Foundation; either version 3, or (at your option) any later
%  version. The SPARK toolset is distributed in the hope that it will be
%  useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
%  Public License for more details. You should have received a copy of the GNU
%  General Public License distributed with the SPARK toolset; see file
%  COPYING3. If not, go to http://www.gnu.org/licenses for a complete copy of
%  the license.
% 
% =============================================================================


%###############################################################################
% PURPOSE
%-------------------------------------------------------------------------------
% Declares dynamic predicates that are visible in the user module.
%



%###############################################################################


%###############################################################################
% DEPENDENCIES
%###############################################################################


%###############################################################################
% TYPES
%###############################################################################


%###############################################################################
% DATA
%###############################################################################


%###############################################################################
% PREDICATES
%###############################################################################

:- dynamic(allow_new_strategies/0).
:- dynamic(already_know_indentation/2).
:- dynamic(buffered_used_fact/3).
:- dynamic(candidate_lower/4).
:- dynamic(candidate_upper/4).
:- dynamic(complexity_fact/4).
:- dynamic(could_infer/2).
:- dynamic(could_not_infer/1).
:- dynamic(current_root/2).
:- dynamic(current_sat_goal/1).
:- dynamic(current_stack_depth/1).
:- dynamic(current_vc_number/1).
:- dynamic(found_contradiction/0).
:- dynamic(forward_inferences/1).
:- dynamic(hn/1).
:- dynamic(inference_depth_limit/2).
:- dynamic(issued_contradiction_message/0).
:- dynamic(issued_vc_proved_message/0).
:- dynamic(join_hyp/4).
:- dynamic(know_eliminated/1).
:- dynamic(know_eliminated_in_subgoaling/2).
:- dynamic(know_norm_expr/2).
:- dynamic(know_substituted/1).
:- dynamic(know_term_breakdown/2).
:- dynamic(known_lower_numeric_limit/4).
:- dynamic(known_upper_numeric_limit/4).
:- dynamic(log_fact/2).
:- dynamic(max_conc_no/1).
:- dynamic(max_hyp_no/1).
:- dynamic(max_written_conc_no/1).
:- dynamic(moved_log_fact/3).
:- dynamic(nhn/1).
:- dynamic(overall_rule_summary/2).
:- dynamic(pairing_depth/1).
:- dynamic(path_line/1).
:- dynamic(pfn/1).
:- dynamic(potential_subst_fact/2).
:- dynamic(proved_by_user_rules/0).
:- dynamic(raw_hyp_already_read/2).
:- dynamic(reduction_hyp/2).
:- dynamic(rule_summary/2).
:- dynamic(simplified_action_part/0).
:- dynamic(stack/2).
:- dynamic(stmt_line/1).
:- dynamic(succ_line/1).
:- dynamic(syntax_error_in_file/1).
:- dynamic(twiddles_conversion/2).
:- dynamic(used/1).
:- dynamic(var_const/3).
:- dynamic(vc_name/1).

%###############################################################################
% END-OF-FILE
